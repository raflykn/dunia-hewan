package com.dunia.hewan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
